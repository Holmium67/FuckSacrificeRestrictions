# Fuck Sacrifice Restrictions

Ever wanted to put more sigils on a card you already put sigils on? This mod removes the restrictions on sacrificing.

Thanks to everyone in the Inscryption Modding Discord helping me with my tinybrain...